# Choropleth-map-of-poverty-rate
Tutorial of generating choropleth maps based on Indonesia's poverty rate 2020-2021 data using Python graphing libraries (Geopandas, Plotly, Folium).

Read the story here: https://medium.com/@maulialwan/choropleth-map-for-indonesias-poverty-rate-visualization-45fe10409853
